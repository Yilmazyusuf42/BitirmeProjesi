using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Roll : Skill
{
    public override void UseSkill()
    {
        base.UseSkill();
    }
}
