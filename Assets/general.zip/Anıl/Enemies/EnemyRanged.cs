using UnityEngine;

public class EnemyRanged : EnemyBase
{
    // Placeholder for future ranged-specific logic (like projectile spread, aim offsets, etc.)
}
